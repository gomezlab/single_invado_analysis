/**
 * ForeroThresholding_.java
 * Created on 19 june 2007, 15:37
 *
 * Forero thresholding algorithm
 * This plugin do not create a new image, if you want create a new image use RATSS_
 *
 * Copyright (c) 2005 by Manuel Guillermo Forero-Vargas
 * e-mail: mgforero@yahoo.es
 *
 * This plugin is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this plugin; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

import ij.*;
import ij.plugin.filter.PlugInFilter;
import ij.process.*;
import java.awt.*;
import ij.gui.*;

public class ForeroThresholding_ implements PlugInFilter
{
    public int setup(String arg, ImagePlus imp)
    {
        if (arg.equals("about"))
        {
            showAbout();
            return DONE;
        }
        return IJ.setupDialog(imp,DOES_8G);
    }

    public void run(ImageProcessor ip)
    {
        int[] filteredHistogram=new int[256];
	int histogramMax;//Maximum peak in the histogram
        int q;
	int threshold=0;
	int qMax=0;;

	int minGris,maxGris;//Limits of the histogram
     
	byte[]  pixels=(byte[])((ByteProcessor) ip).getPixels();
        int size=ip.getHeight()*ip.getWidth();
        int[] histogram=((ByteProcessor) ip).getHistogram();
	    
	//----------------------------------------------------------------------
        //Gets the limits of the histogram
        //Regresa el primer nivel de intensidad que aparece en el histograma
/*        minGris=0;
        while (histogram[minGris]==0)//Barre el histograma
            minGris++;//Cuando encuentra el primer valor!=0 lo regresa
        //Regresa el �ltimo nivel de intensidad que aparece en el histograma a pintar
        maxGris=255;//Levels-1;
        while (histogram[maxGris]==0)
            maxGris--;*/
	//----------------------------------------------------------------------
	for(q=1;q<=254;q++)//Filters the histogram
            filteredHistogram[q]=histogram[q-1]+histogram[q]+histogram[q+1];
	//----------------------------------------------------------------------
	//Finds the threshold that is the minimum value between the peaks
	for (histogramMax=0,q=2;q<25;q++)//256=Niveaux de gris,i=0 normalmente,primer pico
        if (filteredHistogram[q]>histogramMax)
        {
            qMax=q;
            histogramMax=filteredHistogram[q];
        }
	//----------------------------------------------------------------------
        //The threshold is found as the minimum among the first and second modes.
        int histogramMin;
        for (q=qMax,histogramMin=histogramMax;q<50;q++)//255=Niveaux de gris-1,compara hasta 20 o 50,busqueda de minimo
            if (filteredHistogram[q]<histogramMin)
            {
                threshold=q;
                histogramMin=filteredHistogram[q];
            }
	//---------------------------------------------------------------------- 
        ip.threshold(threshold);
        ip.setThreshold(threshold,255,1);//BLACK_AND_WHITE_LUT=1
    }

    void showAbout()
    {
        IJ.showMessage("About ForeroThresholding_...",
        "This plug-in filter calculates the Forero Threshold of 8-bit images.");
    }
}
