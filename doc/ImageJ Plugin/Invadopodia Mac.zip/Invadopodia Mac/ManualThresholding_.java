/**
 * ManualThresholding_.java
 * Created on 30 August 2005, 19:23
 *
 * Manual thresholding algorithm
 * This plugin do not create a new image, if you want create a new image use RATSS_
 *
 * Copyright (c) 2005 by Manuel Guillermo Forero-Vargas
 * e-mail: mgforero@yahoo.es
 *
 * This plugin is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this plugin; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

import ij.*;
import ij.plugin.filter.PlugInFilter;
import ij.process.*;
import ij.gui.*;

public class ManualThresholding_ implements PlugInFilter
{
    protected   ImagePlus   imp;
    protected   int         threshold=128;
    public int setup(String arg, ImagePlus imp)
    {
        if (arg.equals("about"))
        {
            showAbout();
            return DONE;
        }
        //----------------------------------------------------------------------
        /*Creates a dialog box, allowing the user to enter the requested
        threshold.*/
        GenericDialog gd=new GenericDialog("Manual threshold",IJ.getInstance());
        gd.addNumericField("Threshold:",threshold,0,3, "");
        gd.showDialog();
        if (gd.wasCanceled())
            return DONE;
        threshold=(int)gd.getNextNumber();
        //----------------------------------------------------------------------
        this.imp=imp;
        return IJ.setupDialog(imp,DOES_8G);
    }

    public void run(ImageProcessor ip)
    {
	int i;
     
	byte[]  pixels=(byte[])((ByteProcessor) ip).getPixels();
//        byte[]	pixels=(byte[])ip.getPixels();
        int size=ip.getHeight()*ip.getWidth();

/*        for (i=0;i<size;i++)
            pixels[i]=(pixels[i]&0xff)<=threshold?(byte)0:(byte)255;
        imp.show();
        imp.updateAndDraw();
        ip.setThreshold(threshold,255,1);*/
      ip.threshold(threshold);
   }

    void showAbout()
    {
        IJ.showMessage("About ManualThresholding_...",
        "This plug-in binarize an 8-bit image by using a manual threshold.");
    }
}
