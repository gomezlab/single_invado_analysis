/**
* Particle_Remover_Area.java
* Created on 25 April 2009 by Manuel Guillermo Forero-Vargas
* e-mail: mgforero@yahoo.es
*
* Particle remover algorith by area
* Function: This plugin removes objects in an image or stack smaller or bigger than the
* threshold given by the user
*
* This is an extended ParticleAnalyzer that creates a copy of the
* image that has each measured particle erased to the current foreground color.
* For stacks,the particles are erased in place.
*/
import ij.*;
import ij.measure.*;
import ij.plugin.*;
import ij.plugin.filter.*;
import ij.process.*;
import ij.gui.*;

public class Particle_Remover_Area implements PlugIn,Measurements
{
    public void run(String arg)
    {
        ImagePlus imp=IJ.getImage();
        if (imp==null||imp.getType()!=ImagePlus.GRAY8)
        {
            IJ.error("8-bit grayscale image required");
            return;
        }
        int stackSize=imp.getStackSize();
        //----------------------------------------------------------------------
        //Defines the descriptors to be calculated in the particle analysis
        int measurements=Analyzer.getMeasurements();
        measurements=AREA;
        Analyzer.setMeasurements(measurements);
        Analyzer.resetCounter();
        //----------------------------------------------------------------------
        AreaParticleAnalyzer pa=new AreaParticleAnalyzer();
        int flags=pa.setup("",imp);
        if (flags==PlugInFilter.DONE)
            return;
        if ((flags&PlugInFilter.DOES_STACKS)==0)
            stackSize=1;
        //----------------------------------------------------------------------
        for (int i=1;i<=stackSize;i++)
        {
            //----------------------------------------------------------------------
            if (IJ.escapePressed())
			{
                IJ.beep();
                return;
            }
            IJ.showProgress((double)i/stackSize);
            IJ.showStatus("a: "+i+"/"+stackSize);
            if (stackSize>1)
                imp.setSlice(i);
            ImageProcessor ip=imp.getProcessor();
            pa.run(imp,ip);
            if (pa.error)
                break;
            ip.setPixels(pa.ip2.getPixels());
        }
        IJ.showProgress(1.0);
        //----------------------------------------------------------------------
        //Method employed to stop the plugin if the window is closed
        ImageWindow win=imp.getWindow();
        if (win==null)
            return;
        //----------------------------------------------------------------------
        imp.updateAndDraw();
    }	
}

class AreaParticleAnalyzer extends ParticleAnalyzer
{
	//Overrides method with the same name as in AnalyzeParticles that's called once for each particle
    boolean error;
    boolean firstTime=true;
//The following values are static in order to keep them for the next time the plugin is used
    private static int minArea=33,maxArea=500;//Maximum and minimum area in pixels of the accepted objects
    int Descriptor;
    ImageProcessor ip2;

    public boolean setfilters()
    {
        //----------------------------------------------------------------------
        /*Creates a dialog box,allowing the user to enter the required
        maximum and minimum area of the objects to be retained.*/
        GenericDialog gda=new GenericDialog("Particle remover");
        gda.addNumericField("Minimum_area",minArea,0,2,"pixels");
        gda.addNumericField("Maximum_area",maxArea,0,4,"pixels");
        gda.showDialog();
        if (gda.wasCanceled())
            return false;
        minArea=(int)gda.getNextNumber();
        maxArea=(int)gda.getNextNumber();
        //----------------------------------------------------------------------
        return true;
    }
    
    public void run(ImagePlus imp,ImageProcessor ip)
    {
        ip2=ip.duplicate();//Makes a copy of the image
        ip2.setColor(255);//Color used to fill the objects to be eliminated
        slice++;
        error=!analyze(imp,ip);
    }
    
    //Overrides method with the same name in AnalyzeParticles that's called once for each particle
    protected void saveResults(ImageStatistics stats,Roi roi)
    {
        analyzer.saveResults(stats,roi);
        if (firstTime)
        {
            Descriptor=getColumnID("Pixels");
            firstTime=false;
        }
        rt.addValue(Descriptor,stats.pixelCount);//Adds the area measured in pixels
        if (showResults)
            analyzer.displayResults();
        //OJO: Area se puede conseguir con: "rt.getValue(ResultsTable.AREA,region)" o "stats.pixelCount";
        if (stats.pixelCount<minArea|stats.pixelCount>maxArea)//Condition for elimination
        {
            ip2.setRoi(roi.getBoundingRect());
            ip2.fill(roi.getMask());//Deletes the roi in the image
        }
    }

    // Overrides method with the same name in AnalyzeParticles that displays a modal options dialog.
    public boolean showDialog()
    {
        if (!super.showDialog())
            return false;
        return setfilters()?true:false;
    }
    	
    int getColumnID(String name)
    {
        int id=rt.getFreeColumn(name);
        if (id==ResultsTable.COLUMN_IN_USE)
            id=rt.getColumnIndex(name);
        return id;
    }
}
